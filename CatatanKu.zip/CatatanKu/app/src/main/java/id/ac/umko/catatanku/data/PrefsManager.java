package id.ac.umko.catatanku.data;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Satu-satunya tempat akses SharedPreferences.
 * Berkas: shared_prefs/catatan_prefs.xml (MODE_PRIVATE, hanya bisa dibaca aplikasi ini).
 *
 * Yang disimpan di sini hanya data kecil berbentuk key-value:
 *  - nama_panggilan (String)
 *  - tema_gelap     (boolean)
 *
 * Kata sandi SIAKAD sengaja TIDAK disimpan di mana pun.
 */
public class PrefsManager {

    private static final String PREFS_NAME = "catatan_prefs";
    private static final String KEY_NAMA_PANGGILAN = "nama_panggilan";
    private static final String KEY_TEMA_GELAP = "tema_gelap";

    private final SharedPreferences prefs;

    public PrefsManager(Context context) {
        prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void setNamaPanggilan(String nama) {
        // apply(): tulis ke disk di thread latar, UI tidak menunggu
        prefs.edit().putString(KEY_NAMA_PANGGILAN, nama).apply();
    }

    public String getNamaPanggilan() {
        return prefs.getString(KEY_NAMA_PANGGILAN, "");
    }

    public void setTemaGelap(boolean gelap) {
        prefs.edit().putBoolean(KEY_TEMA_GELAP, gelap).apply();
    }

    public boolean isTemaGelap() {
        return prefs.getBoolean(KEY_TEMA_GELAP, false);
    }
}
