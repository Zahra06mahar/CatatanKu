package id.ac.umko.catatanku.data;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Pintu akses riwayat catatan. Semua query Room jalan di thread latar,
 * hasilnya dikirim balik ke main thread supaya UI tidak macet.
 * Satu executor bersama menjaga urutan: simpan dulu, baru baca.
 */
public class CatatanRepository {

    public interface Callback<T> {
        void onResult(T result);
    }

    private static final ExecutorService IO = Executors.newSingleThreadExecutor();

    private final CatatanDao dao;
    private final Handler main = new Handler(Looper.getMainLooper());

    public CatatanRepository(Context context) {
        this.dao = AppDatabase.getInstance(context).catatanDao();
    }

    public void cari(String kata, String kategori, Callback<List<Catatan>> callback) {
        IO.execute(() -> {
            List<Catatan> hasil = dao.cari(kata == null ? "" : kata, kategori);
            main.post(() -> callback.onResult(hasil));
        });
    }

    public void hitung(Callback<Integer> callback) {
        IO.execute(() -> {
            int total = dao.hitung();
            main.post(() -> callback.onResult(total));
        });
    }

    public void getById(long id, Callback<Catatan> callback) {
        IO.execute(() -> {
            Catatan hasil = dao.getById(id);
            main.post(() -> callback.onResult(hasil));
        });
    }

    /** Insert jika id == 0, selain itu update. */
    public void simpan(Catatan catatan, Runnable selesai) {
        IO.execute(() -> {
            if (catatan.getId() == 0) {
                catatan.setId(dao.insert(catatan));
            } else {
                dao.update(catatan);
            }
            if (selesai != null) main.post(selesai);
        });
    }

    public void hapus(long id, Runnable selesai) {
        IO.execute(() -> {
            dao.deleteById(id);
            if (selesai != null) main.post(selesai);
        });
    }
}
