package id.ac.umko.catatanku.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface CatatanDao {

    @Insert
    long insert(Catatan catatan);

    @Update
    void update(Catatan catatan);

    @Query("DELETE FROM catatan WHERE id = :id")
    void deleteById(long id);

    @Query("SELECT COUNT(*) FROM catatan")
    int hitung();

    @Query("SELECT * FROM catatan WHERE id = :id LIMIT 1")
    Catatan getById(long id);

    /** kategori = null berarti semua kategori. Terbaru di atas. */
    @Query("SELECT * FROM catatan "
            + "WHERE (:kategori IS NULL OR kategori = :kategori) "
            + "AND (judul LIKE '%' || :kata || '%' OR isi LIKE '%' || :kata || '%') "
            + "ORDER BY waktu DESC")
    List<Catatan> cari(String kata, String kategori);
}
