package id.ac.umko.catatanku.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/** Satu catatan (tabel "catatan" di Room): judul, isi, kategori, waktu. id = 0 berarti belum tersimpan. */
@Entity(tableName = "catatan")
public class Catatan {

    @PrimaryKey(autoGenerate = true)
    private long id;

    private String judul = "";
    private String isi = "";
    private String kategori = Category.DEFAULT;
    private long waktu;

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getJudul() { return judul; }
    public void setJudul(String judul) { this.judul = judul; }

    public String getIsi() { return isi; }
    public void setIsi(String isi) { this.isi = isi; }

    public String getKategori() { return kategori; }
    public void setKategori(String kategori) { this.kategori = kategori; }

    public long getWaktu() { return waktu; }
    public void setWaktu(long waktu) { this.waktu = waktu; }
}
