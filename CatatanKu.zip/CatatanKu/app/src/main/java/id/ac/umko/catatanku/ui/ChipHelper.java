package id.ac.umko.catatanku.ui;

import android.content.Context;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import id.ac.umko.catatanku.R;
import id.ac.umko.catatanku.util.UiUtil;

/** Membuat "chip" kategori yang dipakai di layar utama dan editor. */
public final class ChipHelper {

    private ChipHelper() {}

    public static TextView create(Context ctx, String label, boolean checked,
                                  View.OnClickListener onClick) {
        TextView chip = new TextView(ctx);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, UiUtil.dp(ctx, 38));
        lp.rightMargin = UiUtil.dp(ctx, 8);
        chip.setLayoutParams(lp);

        chip.setText(label);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(UiUtil.dp(ctx, 18), 0, UiUtil.dp(ctx, 18), 0);
        chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        chip.setTypeface(chip.getTypeface(), android.graphics.Typeface.BOLD);
        chip.setBackgroundResource(R.drawable.bg_chip);
        chip.setOnClickListener(onClick);
        setChecked(chip, checked);
        return chip;
    }

    public static void setChecked(TextView chip, boolean checked) {
        chip.setSelected(checked);
        chip.setTextColor(checked
                ? UiUtil.color(chip.getContext(), R.color.white)
                : UiUtil.themeColor(chip.getContext(), R.attr.cTextSub));
    }
}
