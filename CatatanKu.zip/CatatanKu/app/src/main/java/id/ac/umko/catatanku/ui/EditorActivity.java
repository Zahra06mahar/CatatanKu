package id.ac.umko.catatanku.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import id.ac.umko.catatanku.R;
import id.ac.umko.catatanku.data.Category;
import id.ac.umko.catatanku.data.Catatan;
import id.ac.umko.catatanku.data.CatatanRepository;
import id.ac.umko.catatanku.util.DateUtil;
import id.ac.umko.catatanku.util.ThemeHelper;

/**
 * Layar tulis/ubah catatan (disimpan ke Room).
 * Tombol kembali menyimpan otomatis, jadi tulisan tidak hilang.
 */
public class EditorActivity extends Activity {

    public static final String EXTRA_ID = "extra_id";

    private CatatanRepository repo;
    private Catatan catatan;          // null = catatan baru
    private boolean siap = true;        // false selama data lama masih dimuat dari Room
    private String selectedCategory = Category.DEFAULT;

    private EditText etJudul;
    private EditText etDetail;
    private TextView tvMeta;
    private TextView tvHeader;
    private final List<TextView> chips = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeHelper.apply(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        repo = new CatatanRepository(this);

        etJudul = findViewById(R.id.etTitle);
        etDetail = findViewById(R.id.etContent);
        tvMeta = findViewById(R.id.tvMeta);
        tvHeader = findViewById(R.id.tvHeader);
        ImageButton btnDelete = findViewById(R.id.btnDelete);

        setupChips();
        etDetail.setHint(Category.hintOf(selectedCategory));

        long id = getIntent().getLongExtra(EXTRA_ID, 0);
        tvHeader.setText(id > 0 ? "Ubah catatan" : "Catatan baru");
        if (id > 0) {
            siap = false;
            tvMeta.setText("Memuat...");
            repo.getById(id, hasil -> {
                catatan = hasil;
                siap = true;
                if (hasil != null) {
                    etJudul.setText(hasil.getJudul());
                    etDetail.setText(hasil.getIsi());
                    pilihKategori(hasil.getKategori());
                    tvMeta.setText("Terakhir diubah: " + DateUtil.formatNote(hasil.getWaktu()));
                } else {
                    tvMeta.setText("Catatan baru");
                }
            });
        } else {
            tvMeta.setText("Catatan baru");
            btnDelete.setVisibility(View.GONE);
            etJudul.requestFocus();
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
                    | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }

        findViewById(R.id.btnBack).setOnClickListener(v -> saveAndClose());
        findViewById(R.id.btnSave).setOnClickListener(v -> onSaveClicked());
        btnDelete.setOnClickListener(v -> confirmDelete());
    }

    @Override
    public void onBackPressed() {
        saveAndClose();
    }

    // ---------- kategori ----------

    private void setupChips() {
        LinearLayout container = findViewById(R.id.chipEditor);
        for (String label : Category.LIST) {
            TextView chip = ChipHelper.create(this, label, label.equals(selectedCategory),
                    v -> pilihKategori(label));
            chips.add(chip);
            container.addView(chip);
        }
    }

    private void pilihKategori(String label) {
        selectedCategory = label;
        etDetail.setHint(Category.hintOf(label));
        for (TextView t : chips) {
            ChipHelper.setChecked(t, t.getText().toString().equals(label));
        }
    }

    // ---------- simpan / hapus ----------

    private String judulText() {
        return etJudul.getText().toString().trim();
    }

    private String detailText() {
        return etDetail.getText().toString().trim();
    }

    private boolean tidakBerubah(String judul, String detail) {
        return catatan != null
                && judul.equals(catatan.getJudul())
                && detail.equals(catatan.getIsi())
                && selectedCategory.equals(catatan.getKategori());
    }

    private void persist(String judul, String detail) {
        Catatan target = (catatan != null) ? catatan : new Catatan();
        target.setJudul(judul);
        target.setIsi(detail);
        target.setKategori(selectedCategory);
        target.setWaktu(System.currentTimeMillis());
        repo.simpan(target, null);
    }

    private void onSaveClicked() {
        if (!siap) return;
        String judul = judulText();
        String detail = detailText();

        if (judul.isEmpty() && detail.isEmpty()) {
            Toast.makeText(this, "Catatan masih kosong", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!tidakBerubah(judul, detail)) persist(judul, detail);
        Toast.makeText(this, "Tersimpan", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void saveAndClose() {
        if (!siap) {
            finish();
            return;
        }
        String judul = judulText();
        String detail = detailText();

        if (judul.isEmpty() && detail.isEmpty()) {
            // Catatan kosong tidak perlu disimpan; kalau sebelumnya ada, dihapus.
            if (catatan != null) repo.hapus(catatan.getId(), null);
        } else if (!tidakBerubah(judul, detail)) {
            persist(judul, detail);
        }
        finish();
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setTitle("Hapus catatan?")
                .setMessage("Catatan ini akan dihapus permanen.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Hapus", (dialog, which) -> {
                    if (catatan != null) repo.hapus(catatan.getId(), null);
                    Toast.makeText(this, "Catatan dihapus", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .show();
    }
}
