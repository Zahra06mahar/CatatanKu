package id.ac.umko.catatanku.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/** Format tanggal berbahasa Indonesia. */
public final class DateUtil {

    private static final Locale ID = new Locale("id", "ID");

    private DateUtil() {}

    /** Contoh: "Sabtu, 7 November 2026" */
    public static String formatHeader(long millis) {
        return new SimpleDateFormat("EEEE, d MMMM yyyy", ID).format(new Date(millis));
    }

    /** Contoh: "Hari ini, 14.05" / "Kemarin" / "7 Nov 2026" */
    public static String formatNote(long millis) {
        Calendar then = Calendar.getInstance();
        then.setTimeInMillis(millis);

        Calendar today = Calendar.getInstance();
        if (isSameDay(today, then)) {
            return "Hari ini, " + new SimpleDateFormat("HH.mm", ID).format(new Date(millis));
        }

        Calendar yesterday = Calendar.getInstance();
        yesterday.add(Calendar.DAY_OF_YEAR, -1);
        if (isSameDay(yesterday, then)) {
            return "Kemarin";
        }
        return new SimpleDateFormat("d MMM yyyy", ID).format(new Date(millis));
    }

    private static boolean isSameDay(Calendar a, Calendar b) {
        return a.get(Calendar.YEAR) == b.get(Calendar.YEAR)
                && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR);
    }
}
