package id.ac.umko.catatanku.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import id.ac.umko.catatanku.R;
import id.ac.umko.catatanku.data.Category;
import id.ac.umko.catatanku.data.Catatan;
import id.ac.umko.catatanku.data.CatatanRepository;
import id.ac.umko.catatanku.data.PrefsManager;
import id.ac.umko.catatanku.util.DateUtil;
import id.ac.umko.catatanku.util.ThemeHelper;
import id.ac.umko.catatanku.util.UiUtil;

/**
 * Layar utama: sapaan (dari SharedPreferences) + daftar catatan (dari Room).
 * Pengaturan dibaca ulang di onResume() sehingga selalu sesuai nilai tersimpan.
 */
public class MainActivity extends Activity {

    private PrefsManager prefs;
    private CatatanRepository repo;
    private CatatanAdapter adapter;

    private ListView listCatatan;
    private TextView tvGreeting;
    private TextView tvInfo;
    private TextView tvCount;
    private TextView tvEmpty;
    private TextView tvAvatar;
    private ImageView ivAvatar;
    private EditText etSearch;
    private LinearLayout chipContainer;

    private final List<TextView> chips = new ArrayList<>();
    private String selectedCategory = Category.ALL;
    private boolean temaGelap;
    private boolean animasiAwal = true; // kartu "masuk" hanya saat layar pertama dibuka

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        temaGelap = ThemeHelper.apply(this); // pasang tema sebelum layar dibuat
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = new PrefsManager(this);
        repo = new CatatanRepository(this);

        tvGreeting = findViewById(R.id.tvGreeting);
        tvInfo = findViewById(R.id.tvInfo);
        tvCount = findViewById(R.id.tvCount);
        tvEmpty = findViewById(R.id.tvEmpty);
        tvAvatar = findViewById(R.id.tvAvatar);
        ivAvatar = findViewById(R.id.ivAvatar);
        etSearch = findViewById(R.id.etSearch);
        chipContainer = findViewById(R.id.chipContainer);
        listCatatan = findViewById(R.id.listNotes);

        adapter = new CatatanAdapter(this);
        listCatatan.setAdapter(adapter);

        Animation masuk = AnimationUtils.loadAnimation(this, R.anim.item_enter);
        listCatatan.setLayoutAnimation(new LayoutAnimationController(masuk, 0.12f));

        setupChips();
        setupSearch();

        listCatatan.setOnItemClickListener((parent, view, position, id) ->
                openEditor(adapter.getItem(position).getId()));
        listCatatan.setOnItemLongClickListener((parent, view, position, id) -> {
            confirmDelete(adapter.getItem(position));
            return true;
        });
        findViewById(R.id.btnAdd).setOnClickListener(v -> openEditor(0));
        findViewById(R.id.btnSettings).setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Tema berubah di Pengaturan -> bangun ulang layar dengan tema baru
        if (prefs.isTemaGelap() != temaGelap) {
            recreate();
            return;
        }
        showHeader();
        loadData();
    }

    // ---------- tampilan ----------

    private void showHeader() {
        String nama = prefs.getNamaPanggilan();
        tvGreeting.setText(nama.isEmpty() ? "Halo!" : "Halo, " + nama + "!");
        tvInfo.setText(DateUtil.formatHeader(System.currentTimeMillis()));
        UiUtil.bindAvatar(tvAvatar, ivAvatar, nama);
    }

    private void setupChips() {
        List<String> labels = new ArrayList<>();
        labels.add(Category.ALL);
        for (String c : Category.LIST) labels.add(c);

        for (String label : labels) {
            TextView chip = ChipHelper.create(this, label, label.equals(selectedCategory),
                    v -> {
                        selectedCategory = label;
                        for (TextView t : chips) {
                            ChipHelper.setChecked(t, t.getText().toString().equals(label));
                        }
                        loadData();
                    });
            chips.add(chip);
            chipContainer.addView(chip);
        }
    }

    private void setupSearch() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { loadData(); }
        });
        etSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                UiUtil.hideKeyboard(this);
                return true;
            }
            return false;
        });
    }

    // ---------- data ----------

    private void loadData() {
        String keyword = etSearch.getText().toString().trim();
        String category = Category.ALL.equals(selectedCategory) ? null : selectedCategory;
        boolean filtering = !keyword.isEmpty() || category != null;

        repo.hitung(total -> tvCount.setText(total == 0
                ? "Belum ada catatan"
                : total + " catatan"));

        repo.cari(keyword, category, hasil -> {
            adapter.setItems(hasil);
            if (hasil.isEmpty()) {
                tvEmpty.setText(filtering
                        ? "Catatan tidak ditemukan"
                        : "Belum ada catatan\nKetuk Tambah untuk membuat catatan pertamamu");
                tvEmpty.setVisibility(View.VISIBLE);
            } else {
                tvEmpty.setVisibility(View.GONE);
                if (animasiAwal) {
                    animasiAwal = false;
                    listCatatan.scheduleLayoutAnimation();
                }
            }
        });
    }

    private void openEditor(long id) {
        Intent intent = new Intent(this, EditorActivity.class);
        if (id > 0) intent.putExtra(EditorActivity.EXTRA_ID, id);
        startActivity(intent);
    }

    private void confirmDelete(Catatan catatan) {
        new AlertDialog.Builder(this)
                .setTitle("Hapus catatan?")
                .setMessage("Catatan ini akan dihapus permanen.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Hapus", (dialog, which) ->
                        repo.hapus(catatan.getId(), () -> {
                            Toast.makeText(this, "Catatan dihapus", Toast.LENGTH_SHORT).show();
                            loadData();
                        }))
                .show();
    }
}
