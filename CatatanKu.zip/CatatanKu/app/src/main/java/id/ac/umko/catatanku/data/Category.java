package id.ac.umko.catatanku.data;

import android.content.Context;

import id.ac.umko.catatanku.R;
import id.ac.umko.catatanku.util.UiUtil;

/** Daftar kategori catatan beserta warnanya dan petunjuk isinya. */
public final class Category {

    /** Label filter di layar utama (bukan kategori sungguhan). */
    public static final String ALL = "Semua";

    public static final String[] LIST = {"Kuliah", "Organisasi", "Pribadi", "Lainnya"};

    public static final String DEFAULT = LIST[0];

    private Category() {}

    /** Petunjuk isi catatan (placeholder) sesuai kategori. */
    public static String hintOf(String name) {
        if ("Organisasi".equals(name)) return "Hasil rapat, agenda, atau pembagian tugas…";
        if ("Pribadi".equals(name)) return "Ide, pengingat, atau catatan harian…";
        if ("Lainnya".equals(name)) return "Tulis catatanmu di sini…";
        return "Ringkasan materi, tugas, atau pesan dosen…";
    }

    public static int colorOf(Context ctx, String name) {
        int res;
        if ("Organisasi".equals(name)) {
            res = R.color.cat_organisasi;
        } else if ("Pribadi".equals(name)) {
            res = R.color.cat_pribadi;
        } else if ("Lainnya".equals(name)) {
            res = R.color.cat_lainnya;
        } else {
            res = R.color.cat_kuliah;
        }
        return UiUtil.color(ctx, res);
    }
}
