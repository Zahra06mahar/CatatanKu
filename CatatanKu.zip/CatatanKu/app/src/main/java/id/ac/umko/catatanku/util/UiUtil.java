package id.ac.umko.catatanku.util;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;

import java.util.Locale;

/** Fungsi bantu kecil untuk urusan tampilan. */
public final class UiUtil {

    private UiUtil() {}

    public static int dp(Context ctx, int value) {
        return Math.round(value * ctx.getResources().getDisplayMetrics().density);
    }

    /** Warna tetap dari colors.xml. */
    @SuppressWarnings("deprecation")
    public static int color(Context ctx, int colorRes) {
        return ctx.getResources().getColor(colorRes);
    }

    /** Warna mengikuti tema aktif (terang/gelap), mis. R.attr.cText. */
    public static int themeColor(Context ctx, int attrRes) {
        TypedValue tv = new TypedValue();
        ctx.getTheme().resolveAttribute(attrRes, tv, true);
        return tv.data;
    }

    /** Latar bulat berwarna dengan transparansi (alpha 0-255), untuk label kategori. */
    public static GradientDrawable pill(Context ctx, int color, int alpha, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor((color & 0x00FFFFFF) | (alpha << 24));
        d.setCornerRadius(dp(ctx, radiusDp));
        return d;
    }

    /**
     * Avatar: huruf pertama nama panggilan, atau ikon orang bila nama masih kosong.
     */
    public static void bindAvatar(TextView initial, View placeholder, String nama) {
        String n = nama == null ? "" : nama.trim();
        if (n.isEmpty()) {
            initial.setVisibility(View.GONE);
            placeholder.setVisibility(View.VISIBLE);
        } else {
            String first = new String(Character.toChars(n.codePointAt(0)));
            initial.setText(first.toUpperCase(Locale.getDefault()));
            initial.setVisibility(View.VISIBLE);
            placeholder.setVisibility(View.GONE);
        }
    }

    public static void hideKeyboard(Activity activity) {
        View focus = activity.getCurrentFocus();
        if (focus == null) return;
        InputMethodManager imm =
                (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(focus.getWindowToken(), 0);
    }
}
