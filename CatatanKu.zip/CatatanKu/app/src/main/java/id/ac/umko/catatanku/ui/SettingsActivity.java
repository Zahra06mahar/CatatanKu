package id.ac.umko.catatanku.ui;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.Toast;

import id.ac.umko.catatanku.R;
import id.ac.umko.catatanku.data.PrefsManager;
import id.ac.umko.catatanku.util.ThemeHelper;
import id.ac.umko.catatanku.util.UiUtil;

/** Pengaturan: nama panggilan dan tema gelap (keduanya SharedPreferences). */
public class SettingsActivity extends Activity {

    private PrefsManager prefs;
    private EditText etNama;
    private TextView tvAvatar;
    private ImageView ivAvatar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeHelper.apply(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefs = new PrefsManager(this);

        etNama = findViewById(R.id.etNama);
        tvAvatar = findViewById(R.id.tvAvatar);
        ivAvatar = findViewById(R.id.ivAvatar);
        Switch swTema = findViewById(R.id.swTema);

        etNama.setText(prefs.getNamaPanggilan());
        UiUtil.bindAvatar(tvAvatar, ivAvatar, prefs.getNamaPanggilan());
        swTema.setChecked(prefs.isTemaGelap());

        // Listener dipasang setelah setChecked() supaya tidak terpicu saat layar dibuka
        swTema.setOnCheckedChangeListener((button, checked) -> {
            simpanNama();
            prefs.setTemaGelap(checked);
            recreate(); // pasang ulang layar ini dengan tema baru
        });

        findViewById(R.id.btnSimpanNama).setOnClickListener(v -> {
            simpanNama();
            UiUtil.hideKeyboard(this);
            Toast.makeText(this, "Nama panggilan tersimpan", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }

    @Override
    protected void onPause() {
        super.onPause();
        simpanNama(); // keluar dari layar ini tanpa menekan Simpan pun tetap tersimpan
    }

    private void simpanNama() {
        String nama = etNama.getText().toString().trim();
        if (!nama.equals(prefs.getNamaPanggilan())) {
            prefs.setNamaPanggilan(nama);
        }
        UiUtil.bindAvatar(tvAvatar, ivAvatar, nama);
    }
}
