package id.ac.umko.catatanku.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import id.ac.umko.catatanku.R;
import id.ac.umko.catatanku.data.Category;
import id.ac.umko.catatanku.data.Catatan;
import id.ac.umko.catatanku.util.DateUtil;
import id.ac.umko.catatanku.util.UiUtil;

/** Menampilkan daftar catatan sebagai kartu dengan penanda warna kategori. */
public class CatatanAdapter extends BaseAdapter {

    private final Context context;
    private final LayoutInflater inflater;
    private List<Catatan> items = new ArrayList<>();

    public CatatanAdapter(Context context) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
    }

    public void setItems(List<Catatan> newItems) {
        this.items = newItems;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Catatan getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return items.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder h;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_note, parent, false);
            h = new Holder(convertView);
            convertView.setTag(h);
        } else {
            h = (Holder) convertView.getTag();
        }

        Catatan k = getItem(position);

        h.title.setText(k.getJudul().isEmpty() ? "Tanpa judul" : k.getJudul());

        String preview = k.getIsi().replace('\n', ' ').trim();
        h.preview.setText(preview.isEmpty() ? "Tidak ada detail" : preview);

        int warna = Category.colorOf(context, k.getKategori());
        h.accent.setBackground(UiUtil.pill(context, warna, 255, 2));
        h.category.setText(k.getKategori());
        h.category.setTextColor(warna);
        h.category.setBackground(UiUtil.pill(context, warna, 38, 10));
        h.date.setText(DateUtil.formatNote(k.getWaktu()));
        return convertView;
    }

    private static class Holder {
        final TextView title, preview, category, date;
        final View accent;

        Holder(View root) {
            title = root.findViewById(R.id.tvTitle);
            preview = root.findViewById(R.id.tvPreview);
            accent = root.findViewById(R.id.vAccent);
            category = root.findViewById(R.id.tvCategory);
            date = root.findViewById(R.id.tvDate);
        }
    }
}
