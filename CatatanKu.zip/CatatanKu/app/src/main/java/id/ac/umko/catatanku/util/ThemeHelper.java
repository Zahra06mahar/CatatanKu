package id.ac.umko.catatanku.util;

import android.app.Activity;

import id.ac.umko.catatanku.R;
import id.ac.umko.catatanku.data.PrefsManager;

/** Memasang tema terang/gelap sesuai nilai tema_gelap di SharedPreferences. */
public final class ThemeHelper {

    private ThemeHelper() {}

    /**
     * Panggil di awal onCreate (sebelum super.onCreate).
     *
     * @return true jika tema gelap yang dipasang
     */
    public static boolean apply(Activity activity) {
        boolean gelap = new PrefsManager(activity).isTemaGelap();
        activity.setTheme(gelap ? R.style.AppDark : R.style.AppLight);
        return gelap;
    }
}
