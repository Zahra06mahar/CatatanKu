# CatatanKu

Aplikasi catatan harian mahasiswa (Java + XML): catatan materi kuliah, catatan organisasi, dan catatan pribadi, untuk praktik **P10 - SharedPreferences pada Aplikasi Mobile**.

## Simpan di mana? (4 data, 1 aplikasi)

| Data | Disimpan di | Alasan |
|---|---|---|
| Nama panggilan | SharedPreferences (`catatan_prefs.xml`, key `nama_panggilan`) | kecil, key-value |
| Tema gelap | SharedPreferences (`catatan_prefs.xml`, key `tema_gelap`) | kecil, key-value |
| Isi catatan | Room DB (`catatanku.db`, tabel `catatan`) | banyak baris, perlu query |
| Kata sandi SIAKAD | **tidak disimpan** | rahasia |

## Poin SharedPreferences
- Semua akses lewat satu class: `data/PrefsManager.java`
- Mode `MODE_PRIVATE` (berkas privat aplikasi)
- Menulis dengan `apply()` (asinkron, UI tidak menunggu), bukan `commit()`
- Dibaca ulang di `onResume()` / `onCreate()`, jadi "Halo, <nama>!" dan tema tetap ada setelah aplikasi dibuka lagi

## Tampilan
- Header gradasi indigo-ungu dengan avatar (huruf pertama nama panggilan) dan sapaan "Halo, <nama>!"
- Kartu catatan dengan garis dan label warna kategori, pencarian melayang, tombol "Tambah"
- Layar Pengaturan memakai kartu profil, saklar tema, dan ringkasan penyimpanan data
- Tanpa library tambahan (hanya Room), jadi tetap ringan dan mudah dijelaskan

## Struktur
```
app/src/main/java/id/ac/umko/catatanku/
├── data/  PrefsManager, Catatan, CatatanDao, AppDatabase, CatatanRepository, Category
├── ui/    MainActivity, EditorActivity, SettingsActivity, CatatanAdapter, ChipHelper
└── util/  ThemeHelper, DateUtil, UiUtil
```

## Menjalankan
1. Android Studio -> File -> Open -> pilih folder `CatatanKu`
2. Settings -> Build Tools -> Gradle -> Gradle JDK: jbr-17 / jbr-21
3. Sync (perlu internet untuk mengunduh Room), lalu Run (minSdk 21)
